<?php
namespace DailyBulletinSpace\Modules;

use DailyBulletinSpace\Modules\CSS_Vars;
use DailyBulletinSpace\Modules\Gutenberg;
use DailyBulletinSpace\Modules\Swiper;
use DailyBulletinSpace\Modules\Page_Preloader;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Theme modules.
 *
 * Main class for theme modules.
 */
class Modules {

	/**
	 * Theme modules constructor.
	 *
	 * Run modules for theme.
	 */
	public function __construct() {
		new CSS_Vars();

		new Swiper();

		new Gutenberg();

		new Page_Preloader();
	}

}
