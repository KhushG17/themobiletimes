<?php
namespace DailyBulletinSpace\PaidMembershipsPro\CmsmastersFramework;

use DailyBulletinSpace\Core\Utils\File_Manager;
use DailyBulletinSpace\PaidMembershipsPro\CmsmastersFramework\Kits\Kit as Plugin_Kit;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Plugin handler class is responsible for paid Memberships pro different methods.
 */
class Plugin {

	private $css_path_prefix = 'paid-memberships-pro/cmsmasters-framework/';

	/**
	 * Plugin constructor.
	 */
	public function __construct() {
		if ( ! function_exists( 'pmpro_is_plugin_active' ) && ! function_exists( 'pmpro_courses_setup_modules' ) ) {
			return;
		}

		new Plugin_Kit();

		add_filter( 'cmsmasters_stylesheet_templates_paths_filter', array( $this, 'stylesheet_templates_paths_filter' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
	}

	/**
	 * Stylesheet templates paths filter.
	 *
	 * @param array $templates_paths Templates paths.
	 *
	 * @return array Filtered templates paths.
	 */
	public function stylesheet_templates_paths_filter( $templates_paths ) {
		$path = File_Manager::get_responsive_css_path( $this->css_path_prefix );

		return array_merge( $templates_paths, array(
			$path . 'paid-memberships-pro.css',
			$path . 'paid-memberships-pro.min.css',
			$path . 'paid-memberships-pro-rtl.css',
			$path . 'paid-memberships-pro-rtl.min.css',
			$path . 'courses-for-membership-add-on.css',
			$path . 'courses-for-membership-add-on.min.css',
			$path . 'courses-for-membership-add-on-rtl.css',
			$path . 'courses-for-membership-add-on-rtl.min.css',
		) );
	}

	/**
	 * Enqueue theme compatibility styles.
	 *
	 * @param array $styles Array of registered styles.
	 *
	 * @return array
	 */
	public function enqueue_styles() {
		if( function_exists( 'pmpro_is_plugin_active' ) ) {

			wp_enqueue_style(
				'daily-bulletin-paid-memberships-pro',
				File_Manager::get_css_template_assets_url( 'paid-memberships-pro', null, 'default', true, $this->css_path_prefix ),
				array(),
				'1.0.0'
			);


			$pmpro_style_variation = get_option( 'pmpro_style_variation', 'variation_1' );


			if ( $pmpro_style_variation === 'variation_1' ) {
				wp_dequeue_style( 'pmpro_frontend_' . esc_attr( $pmpro_style_variation ) );
			}

		}

		if( function_exists( 'pmpro_courses_setup_modules' ) ) {
			wp_enqueue_style(
				'daily-bulletin-courses-for-membership-add-on',
				File_Manager::get_css_template_assets_url( 'courses-for-membership-add-on', null, 'default', true, $this->css_path_prefix ),
				array(),
				'1.0.0'
			);
		}
	}
}
