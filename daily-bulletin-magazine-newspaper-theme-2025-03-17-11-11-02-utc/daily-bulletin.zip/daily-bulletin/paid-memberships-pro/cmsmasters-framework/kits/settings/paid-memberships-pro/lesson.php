<?php
namespace DailyBulletinSpace\PaidMembershipsPro\CmsmastersFramework\Kits\Settings\PaidMembershipsPro;

use DailyBulletinSpace\Kits\Settings\Base\Settings_Tab_Base;

use Elementor\Controls_Manager;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Gutenberg settings.
 */
class Lesson extends Settings_Tab_Base {

	/**
	 * Get toggle name.
	 *
	 * Retrieve the toggle name.
	 *
	 * @return string Toggle name.
	 */
	public static function get_toggle_name() {
		return 'lesson';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the toggle title.
	 */
	public function get_title() {
		return esc_html__( 'Lesson', 'daily-bulletin' );
	}

	/**
	 * Get control ID prefix.
	 *
	 * Retrieve the control ID prefix.
	 *
	 * @return string Control ID prefix.
	 */
	protected static function get_control_id_prefix() {
		$toggle_name = self::get_toggle_name();

		return parent::get_control_id_prefix() . "_{$toggle_name}";
	}

	/**
	 * Register toggle controls.
	 *
	 * Registers the controls of the kit settings tab toggle.
	 */
	protected function register_toggle_controls() {
		$this->add_control(
			'wrapper_heading_control',
			array(
				'label' => esc_html__( 'Wrapper', 'daily-bulletin' ),
				'type' => Controls_Manager::HEADING,
			)
		);

		$this->add_controls_group( 'wrapper', self::CONTROLS_CONTAINER_BOX, array(
			'popover' => false,
			'excludes' => array( 'alignment', 'margin' ),
		) );

		$this->add_responsive_control(
			'wrapper_gap',
			array(
				'label' => esc_html__( 'Gap', 'daily-bulletin' ),
				'type' => Controls_Manager::SLIDER,
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 300,
					),
				),
				'size_units' => array(
					'%',
					'px',
				),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'wrapper_gap' ) . ': {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'wrapper_width',
			array(
				'label' => esc_html__( 'Width', 'daily-bulletin' ),
				'type' => Controls_Manager::SLIDER,
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 2000,
					),
				),
				'size_units' => array(
					'%',
					'px',
				),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'wrapper_width' ) . ': {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'title_heading_control',
			array(
				'label' => esc_html__( 'Title', 'daily-bulletin' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_responsive_control(
			'alignment',
			array(
				'label' => __( 'Alignment', 'daily-bulletin' ),
				'type' => Controls_Manager::CHOOSE,
				'label_block' => false,
				'options' => array(
					'left' => array(
						'title' => __( 'Left', 'daily-bulletin' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'daily-bulletin' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __( 'Right', 'daily-bulletin' ),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => 'center',
				'toggle' => false,
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'title_alignment' ) . ': {{VALUE}};',
				),
			)
		);

		$this->add_var_group_control( 'title', self::VAR_TYPOGRAPHY );

		$this->add_control(
			'color_title',
			array(
				'label' => esc_html__( 'Color', 'daily-bulletin' ),
				'type' => Controls_Manager::COLOR,
				'dynamic' => array(),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'color_title' ) . ': {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'title_gap',
			array(
				'label' => esc_html__( 'Gap', 'daily-bulletin' ),
				'type' => Controls_Manager::SLIDER,
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 200,
					),
					'rem' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'size_units' => array(
					'%',
					'px',
					'rem',
				),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'title_gap' ) . ': {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'list_heading_control',
			array(
				'label' => esc_html__( 'List', 'daily-bulletin' ),
				'type' => Controls_Manager::HEADING,
				'separator' => 'before',
			)
		);

		$this->add_var_group_control( 'list', self::VAR_TYPOGRAPHY );

		$this->add_control(
			'color_list',
			array(
				'label' => esc_html__( 'Color', 'daily-bulletin' ),
				'type' => Controls_Manager::COLOR,
				'dynamic' => array(),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'color_list' ) . ': {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'color_list_hover',
			array(
				'label' => esc_html__( 'Hover Color', 'daily-bulletin' ),
				'type' => Controls_Manager::COLOR,
				'dynamic' => array(),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'color_list_hover' ) . ': {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'color_list_icon',
			array(
				'label' => esc_html__( 'Color Icon', 'daily-bulletin' ),
				'type' => Controls_Manager::COLOR,
				'dynamic' => array(),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'color_list_icon' ) . ': {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'color_list_icon_completed',
			array(
				'label' => esc_html__( 'Color Completed Icon', 'daily-bulletin' ),
				'type' => Controls_Manager::COLOR,
				'dynamic' => array(),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'color_list_icon_completed' ) . ': {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'border_color_list',
			array(
				'label' => esc_html__( 'Separator Color', 'daily-bulletin' ),
				'type' => Controls_Manager::COLOR,
				'dynamic' => array(),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'border_color_list' ) . ': {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'list_icon_size',
			array(
				'label' => esc_html__( 'Icon Size', 'daily-bulletin' ),
				'type' => Controls_Manager::SLIDER,
				'range' => array(
					'px' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'size_units' => array(
					'px',
				),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'list_icon_size' ) . ': {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'list_border_width',
			array(
				'label' => esc_html__( 'Separator Width', 'daily-bulletin' ),
				'type' => Controls_Manager::SLIDER,
				'range' => array(
					'px' => array(
						'min' => 0,
						'max' => 10,
					),
				),
				'size_units' => array(
					'px',
				),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'list_border_width' ) . ': {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'list_gap',
			array(
				'label' => esc_html__( 'Gap', 'daily-bulletin' ),
				'type' => Controls_Manager::SLIDER,
				'range' => array(
					'%' => array(
						'min' => 0,
						'max' => 100,
					),
					'px' => array(
						'min' => 0,
						'max' => 200,
					),
					'rem' => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'size_units' => array(
					'%',
					'px',
					'rem',
				),
				'selectors' => array(
					':root' => '--' . $this->get_control_prefix_parameter( '', 'list_gap' ) . ': {{SIZE}}{{UNIT}};',
				),
			)
		);
	}

}
