<?php
namespace DailyBulletinSpace\PaidMembershipsPro\CmsmastersFramework\Kits\Settings\PaidMembershipsPro;

use DailyBulletinSpace\PaidMembershipsPro\CmsmastersFramework\Kits\Kit as Plugin_Kit;
use DailyBulletinSpace\Kits\Settings\Base\Base_Section;


if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}


/**
 * Elements section.
 */
class Section extends Base_Section {

	/**
	 * Get name.
	 *
	 * Retrieve the section name.
	 */
	public static function get_name() {
		return 'paid-memberships-pro';
	}

	/**
	 * Get title.
	 *
	 * Retrieve the section title.
	 */
	public static function get_title() {
		return esc_html__( 'Paid Memberships Pro', 'daily-bulletin' );
	}

	/**
	 * Get icon.
	 *
	 * Retrieve the section icon.
	 */
	public static function get_icon() {
		return 'eicon-plug';
	}

	/**
	 * Get toggles.
	 *
	 * Retrieve the section toggles.
	 */
	public static function get_toggles() {
		return array(
			'lesson',
		);
	}

	/**
	 * Get kit namespace.
	 *
	 * @return string Kit namespace.
	 */
	public function get_kit_namespace() {
		return Plugin_Kit::KIT_NAMESPACE;
	}

}
