<?php
namespace DailyBulletinSpace\ThemeConfig;

use DailyBulletinSpace\Woocommerce\CmsmastersFramework\Plugin as Woocommerce_Plugin;
use DailyBulletinSpace\PaidMembershipsPro\CmsmastersFramework\Plugin as Paid_Memberships_Pro_Plugin;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

/**
 * Theme Plugins.
 *
 * Main class for theme plugins.
 */
class Theme_Plugins {

	/**
	 * Theme_Plugins constructor.
	 */
	public function __construct() {
		new Woocommerce_Plugin();

		new Paid_Memberships_Pro_Plugin();
	}

}
