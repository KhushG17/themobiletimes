<?php
/**
 * Plugin Name: TMT Global Schema
 * Description: Injects Organization + WebSite JSON-LD schema on every page for Google News & SEO.
 * Version: 1.0
 */
if (!defined("ABSPATH")) exit;

add_action("wp_head", "tmt_inject_global_schema", 1);
function tmt_inject_global_schema() {
    $schema = array(
        "@context" => "https://schema.org",
        "@graph"   => array(
            array(
                "@type"       => "NewsMediaOrganization",
                "@id"         => "https://themobiletimes.com/#organization",
                "name"        => "The Mobile Times",
                "url"         => "https://themobiletimes.com",
                "logo"        => array(
                    "@type"  => "ImageObject",
                    "url"    => "https://themobiletimes.com/wp-content/uploads/circle-logo.png",
                    "width"  => 512,
                    "height" => 512
                ),
                "sameAs" => array(
                    "https://x.com/themobile_times",
                    "https://www.linkedin.com/company/themobiletimes",
                    "https://www.instagram.com/themobiletimes",
                    "https://www.facebook.com/themobiletime"
                ),
                "foundingDate"          => "2009",
                "description"           => "India's leading telecom trade publication covering 5G, smartphones, AI, cybersecurity and telecom policy.",
                "address"               => array("@type" => "PostalAddress", "addressCountry" => "IN", "addressLocality" => "Jaipur"),
                "publishingPrinciples"  => "https://themobiletimes.com/about/",
                "masthead"              => "https://themobiletimes.com/about/"
            ),
            array(
                "@type"     => "WebSite",
                "@id"       => "https://themobiletimes.com/#website",
                "url"       => "https://themobiletimes.com",
                "name"      => "The Mobile Times",
                "publisher" => array("@id" => "https://themobiletimes.com/#organization"),
                "potentialAction" => array(
                    "@type"       => "SearchAction",
                    "target"      => array(
                        "@type"       => "EntryPoint",
                        "urlTemplate" => "https://themobiletimes.com/?s={search_term_string}"
                    ),
                    "query-input" => "required name=search_term_string"
                )
            )
        )
    );
    echo '<script type="application/ld+json">' . json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE) . '</script>' . "\n";
}
